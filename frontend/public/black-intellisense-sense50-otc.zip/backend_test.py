#!/usr/bin/env python3
"""
Black IntelliSense OTC Bridge Engine - Backend API Tests
Tests all critical API endpoints for the trading platform
"""

import requests
import sys
import json
from datetime import datetime

class BlackIntelliSenseAPITester:
    def __init__(self, base_url="https://smart-settlement-otc.preview.emergentagent.com"):
        self.base_url = base_url
        self.token = None
        self.tests_run = 0
        self.tests_passed = 0
        self.user_id = None

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.base_url}/api/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=10)
            elif method == 'PATCH':
                response = requests.patch(url, json=data, headers=test_headers, timeout=10)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and len(str(response_data)) < 500:
                        print(f"   Response: {response_data}")
                    return True, response_data
                except:
                    return True, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except requests.exceptions.RequestException as e:
            print(f"❌ Failed - Network Error: {str(e)}")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_root_endpoint(self):
        """Test API root endpoint"""
        success, response = self.run_test(
            "API Root",
            "GET",
            "",
            200
        )
        return success

    def test_create_admin(self):
        """Test creating initial admin user"""
        success, response = self.run_test(
            "Create Initial Admin",
            "POST",
            "auth/create-admin",
            200
        )
        return success

    def test_login(self):
        """Test login with admin credentials"""
        success, response = self.run_test(
            "Admin Login",
            "POST",
            "auth/login",
            200,
            data={"email": "admin@blackintellisense.com", "password": "admin123"}
        )
        if success and 'access_token' in response:
            self.token = response['access_token']
            if 'user' in response:
                self.user_id = response['user'].get('id')
            print(f"   Token acquired: {self.token[:20]}...")
            return True
        return False

    def test_get_user_info(self):
        """Test getting current user info"""
        success, response = self.run_test(
            "Get User Info",
            "GET",
            "auth/me",
            200
        )
        return success

    def test_markup_config(self):
        """Test markup configuration endpoints"""
        # Get current config
        success, response = self.run_test(
            "Get Markup Config",
            "GET",
            "markup/",
            200
        )
        
        if not success:
            return False

        # Update markup config
        update_data = {
            "fixed_markup": 1.0,
            "percentage_markup": 1.5,
            "tiered_markup": {"retail": 2.0, "vip": 1.0}
        }
        
        success, response = self.run_test(
            "Update Markup Config",
            "PATCH",
            "markup/",
            200,
            data=update_data
        )
        return success

    def test_price_feeds(self):
        """Test price feed endpoints"""
        # Get all price feeds
        success, response = self.run_test(
            "Get Price Feeds",
            "GET",
            "prices/",
            200
        )
        
        if not success:
            return False

        # Get best price
        success, response = self.run_test(
            "Get Best Price",
            "GET",
            "prices/best",
            200
        )
        
        if not success:
            return False

        # Get price history
        success, response = self.run_test(
            "Get Price History",
            "GET",
            "prices/history",
            200
        )
        return success

    def test_wallets(self):
        """Test wallet endpoints"""
        # Get wallets
        success, response = self.run_test(
            "Get Wallets",
            "GET",
            "wallets/",
            200
        )
        
        if not success:
            return False

        # Get total balance
        success, response = self.run_test(
            "Get Total Balance",
            "GET",
            "wallets/total-balance",
            200
        )
        return success

    def test_exchanges(self):
        """Test exchange endpoints"""
        success, response = self.run_test(
            "Get Exchanges",
            "GET",
            "exchanges/",
            200
        )
        return success

    def test_orders(self):
        """Test order endpoints"""
        success, response = self.run_test(
            "Get Orders",
            "GET",
            "orders/",
            200
        )
        return success

    def test_trades(self):
        """Test trade endpoints"""
        success, response = self.run_test(
            "Get Trades",
            "GET",
            "trades/",
            200
        )
        return success

    def test_payments(self):
        """Test payment endpoints"""
        success, response = self.run_test(
            "Get Payments",
            "GET",
            "payments/",
            200
        )
        return success

    def test_settlements(self):
        """Test settlement endpoints"""
        success, response = self.run_test(
            "Get Settlements",
            "GET",
            "settlements/",
            200
        )
        return success

def main():
    print("🚀 Starting Black IntelliSense API Tests")
    print("=" * 50)
    
    tester = BlackIntelliSenseAPITester()
    
    # Test sequence
    tests = [
        ("API Root", tester.test_root_endpoint),
        ("Create Admin", tester.test_create_admin),
        ("Login", tester.test_login),
        ("User Info", tester.test_get_user_info),
        ("Markup Config", tester.test_markup_config),
        ("Price Feeds", tester.test_price_feeds),
        ("Wallets", tester.test_wallets),
        ("Exchanges", tester.test_exchanges),
        ("Orders", tester.test_orders),
        ("Trades", tester.test_trades),
        ("Payments", tester.test_payments),
        ("Settlements", tester.test_settlements),
    ]

    failed_tests = []
    
    for test_name, test_func in tests:
        try:
            if not test_func():
                failed_tests.append(test_name)
        except Exception as e:
            print(f"❌ {test_name} - Exception: {str(e)}")
            failed_tests.append(test_name)

    # Print final results
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {tester.tests_passed}/{tester.tests_run} passed")
    
    if failed_tests:
        print(f"❌ Failed Tests: {', '.join(failed_tests)}")
        return 1
    else:
        print("✅ All tests passed!")
        return 0

if __name__ == "__main__":
    sys.exit(main())