import React, { useEffect, useState } from 'react';
import Layout from '../components/layout/Layout';
import api from '../lib/api';
import { formatDateTime } from '../lib/utils';
import { CheckCircle, XCircle, Clock } from 'lucide-react';
import { toast } from 'sonner';

const MarkCRMPage = () => {
  const [settlements, setSettlements] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const settlementsRes = await api.get('/settlements/');
      setSettlements(settlementsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const handleApprove = async (settlementId) => {
    try {
      await api.patch(`/settlements/${settlementId}`, {
        status: 'approved'
      });
      toast.success('Settlement approved!');
      fetchData();
    } catch (error) {
      toast.error('Failed to approve settlement');
    }
  };

  const statusIcons = {
    pending: <Clock className="h-4 w-4 text-warning" />,
    approved: <CheckCircle className="h-4 w-4 text-success" />,
    completed: <CheckCircle className="h-4 w-4 text-success" />,
    rejected: <XCircle className="h-4 w-4 text-destructive" />
  };

  return (
    <Layout>
      <div data-testid="markcrm-page" className="space-y-6">
        <div>
          <h1 className="font-heading text-4xl font-bold tracking-tight">MarkCRM Settlement System</h1>
          <p className="mt-2 text-base text-muted-foreground">
            Automated settlement and reconciliation
          </p>
        </div>

        {/* Settlements Table */}
        <div className="rounded-sm border border-border bg-card/40 backdrop-blur-sm">
          <div className="border-b border-border p-4">
            <h3 className="font-heading text-xl font-semibold">All Settlements</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-muted/20 text-left">
                  <th className="p-3 font-mono text-xs font-medium text-muted-foreground">TRADE ID</th>
                  <th className="p-3 font-mono text-xs font-medium text-muted-foreground">STATUS</th>
                  <th className="p-3 font-mono text-xs font-medium text-muted-foreground">DATE</th>
                  <th className="p-3 font-mono text-xs font-medium text-muted-foreground">ACTION</th>
                </tr>
              </thead>
              <tbody>
                {settlements.map((settlement) => (
                  <tr key={settlement.id} className="border-b border-border/50 transition-colors hover:bg-muted/30">
                    <td className="p-3 font-mono text-sm">{settlement.trade_id.substring(0, 12)}...</td>
                    <td className="p-3">
                      <span
                        className={`inline-flex items-center gap-1 rounded-sm px-2 py-1 font-mono text-xs font-medium ${
                          settlement.status === 'pending'
                            ? 'bg-warning/10 text-warning'
                            : settlement.status === 'approved' || settlement.status === 'completed'
                            ? 'bg-success/10 text-success'
                            : 'bg-destructive/10 text-destructive'
                        }`}
                      >
                        {statusIcons[settlement.status]}
                        {settlement.status.charAt(0).toUpperCase() + settlement.status.slice(1)}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-xs text-muted-foreground">
                      {formatDateTime(settlement.created_at)}
                    </td>
                    <td className="p-3">
                      {settlement.status === 'pending' && (
                        <button
                          data-testid={`approve-settlement-${settlement.id}`}
                          onClick={() => handleApprove(settlement.id)}
                          className="rounded-sm bg-success px-3 py-1 font-mono text-xs font-medium text-white hover:bg-success/90"
                        >
                          Approve
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
                {settlements.length === 0 && (
                  <tr>
                    <td colSpan={4} className="p-6 text-center text-muted-foreground">
                      No settlements available
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default MarkCRMPage;
