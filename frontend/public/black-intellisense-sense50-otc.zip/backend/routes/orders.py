from fastapi import APIRouter, HTTPException, Depends, status
from models import Order, OrderCreate, OrderStatus
from routes.auth import get_current_user
import uuid
from datetime import datetime, timezone
from typing import List

router = APIRouter()

@router.post("/", response_model=Order)
async def create_order(data: OrderCreate, current_user: dict = Depends(get_current_user)):
    from server import get_db
    db = get_db()
    
    order_id = str(uuid.uuid4())
    total = data.amount * data.price
    
    order_doc = {
        "id": order_id,
        "user_id": current_user["user_id"],
        "symbol": data.symbol,
        "side": data.side,
        "amount": data.amount,
        "price": data.price,
        "total": total,
        "status": OrderStatus.PENDING,
        "filled_amount": 0.0,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.orders.insert_one(order_doc)
    
    return Order(**order_doc)

@router.get("/", response_model=List[Order])
async def get_orders(current_user: dict = Depends(get_current_user)):
    from server import get_db
    db = get_db()
    
    orders = await db.orders.find({"user_id": current_user["user_id"]}).sort("created_at", -1).to_list(100)
    
    return [Order(**order) for order in orders]

@router.get("/{order_id}", response_model=Order)
async def get_order(order_id: str, current_user: dict = Depends(get_current_user)):
    from server import get_db
    db = get_db()
    
    order = await db.orders.find_one({"id": order_id, "user_id": current_user["user_id"]})
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )
    
    return Order(**order)

@router.patch("/{order_id}/cancel")
async def cancel_order(order_id: str, current_user: dict = Depends(get_current_user)):
    from server import get_db
    db = get_db()
    
    order = await db.orders.find_one({"id": order_id, "user_id": current_user["user_id"]})
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )
    
    if order["status"] != OrderStatus.PENDING:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only pending orders can be cancelled"
        )
    
    await db.orders.update_one(
        {"id": order_id},
        {"$set": {"status": OrderStatus.CANCELLED, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    return {"message": "Order cancelled successfully"}
